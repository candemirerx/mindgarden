﻿# Telefona USB internet (gnirehtet) yoneticisi: durum, baslat, kapat, kur, kaldir.
# Yonetici izni gerekmez. -Islem verilmezse menu acilir.
param(
    [ValidateSet('', 'Durum', 'Baslat', 'Durdur', 'Kur', 'Kaldir')]
    [string]$Islem = ''
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$taskDir = Join-Path $PSScriptRoot 'vendor/gnirehtet'
$taskExe = Join-Path $taskDir 'gnirehtet.exe'
$taskPackage = 'com.genymobile.gnirehtet'
if (-not (Test-Path -LiteralPath $taskExe)) {
    Write-Host 'gnirehtet bulunamadi. ZIP dosyasinin tamamini bir klasore cikarin.' -ForegroundColor Yellow
    exit 2
}
Get-ChildItem -LiteralPath $taskDir -File | Unblock-File -ErrorAction SilentlyContinue
# adb/gnirehtet stderr'e bilgi yazar; Windows PowerShell 5.1 bunu Stop modunda hata sayar.
$ErrorActionPreference = 'Continue'
$env:ADB = Join-Path $taskDir 'adb.exe'
$env:GNIREHTET_APK = Join-Path $taskDir 'gnirehtet.apk'

function Invoke-Adb {
    param([string[]]$Arguments)
    $out = & $env:ADB @Arguments 2>&1 | ForEach-Object { "$_" }
    return @($out)
}

function Get-Telefonlar {
    Invoke-Adb @('start-server') | Out-Null
    $list = @()
    foreach ($line in (Invoke-Adb @('devices'))) {
        if ($line -match '^(\S+)\s+(device|unauthorized|offline)$') {
            $list += [pscustomobject]@{ Seri = $Matches[1]; Durum = $Matches[2] }
        }
    }
    return $list
}

function Get-RelayIslemleri {
    @(Get-Process -Name 'gnirehtet' -ErrorAction SilentlyContinue)
}

function Show-Durum {
    $relay = Get-RelayIslemleri
    if ($relay.Count -gt 0) {
        Write-Host "Bilgisayar: internet verme acik (gnirehtet PID $($relay.Id -join ', '))." -ForegroundColor Green
    } else {
        Write-Host 'Bilgisayar: internet verme kapali.'
    }
    $phones = Get-Telefonlar
    if ($phones.Count -eq 0) {
        Write-Host 'Kabloyla bagli telefon yok. Telefonda VPN kaldiysa bildirimden Durdur deyin' -ForegroundColor Yellow
        Write-Host 'veya Ayarlar > Baglantilar > VPN > Gnirehtet > Baglantiyi kes yapin.' -ForegroundColor Yellow
        return
    }
    foreach ($p in $phones) {
        if ($p.Durum -ne 'device') {
            Write-Host "Telefon $($p.Seri): $($p.Durum) - telefonda USB hata ayiklama iznini onaylayin." -ForegroundColor Yellow
            continue
        }
        $installed = (Invoke-Adb @('-s', $p.Seri, 'shell', 'pm', 'list', 'packages', $taskPackage)) -match [regex]::Escape("package:$taskPackage")
        $running = ((Invoke-Adb @('-s', $p.Seri, 'shell', 'pidof', $taskPackage)) -join '').Trim() -match '^\d'
        $reverse = (Invoke-Adb @('-s', $p.Seri, 'reverse', '--list')) -match 'gnirehtet'
        $kurulu = if ($installed) { 'kurulu' } else { 'kurulu degil' }
        $calisiyor = if ($running) { 'uygulama calisiyor (VPN acik olabilir)' } else { 'uygulama kapali' }
        $tunel = if ($reverse) { 'USB tuneli var' } else { 'USB tuneli yok' }
        Write-Host "Telefon $($p.Seri): $kurulu, $calisiyor, $tunel."
    }
}

function Stop-Hepsi {
    $phones = @(Get-Telefonlar | Where-Object { $_.Durum -eq 'device' })
    foreach ($p in $phones) {
        & $taskExe stop $p.Seri 2>&1 | Out-Null
        Invoke-Adb @('-s', $p.Seri, 'reverse', '--remove', 'localabstract:gnirehtet') | Out-Null
        Invoke-Adb @('-s', $p.Seri, 'shell', 'am', 'force-stop', $taskPackage) | Out-Null
        Write-Host "Telefon $($p.Seri): VPN kapatildi." -ForegroundColor Green
    }
    $relay = Get-RelayIslemleri
    if ($relay.Count -gt 0) {
        $relay | Stop-Process -Force -ErrorAction SilentlyContinue
        Write-Host 'Bilgisayardaki internet verme penceresi/islemi kapatildi.' -ForegroundColor Green
    }
    if ($phones.Count -eq 0) {
        Write-Host 'Kabloyla bagli telefon yok; telefondaki VPN buradan kapatilamaz.' -ForegroundColor Yellow
        Write-Host 'Telefonda bildirimden Durdur deyin veya Ayarlar > Baglantilar > VPN > Gnirehtet > Baglantiyi kes.' -ForegroundColor Yellow
    }
}

function Invoke-HerTelefon {
    param([string]$Komut, [string]$Basari)
    $phones = @(Get-Telefonlar | Where-Object { $_.Durum -eq 'device' })
    if ($phones.Count -eq 0) {
        Write-Host 'Kabloyla bagli ve izin verilmis telefon yok. USB hata ayiklamayi acip onaylayin.' -ForegroundColor Yellow
        return 1
    }
    $code = 0
    foreach ($p in $phones) {
        & $taskExe $Komut $p.Seri 2>&1 | ForEach-Object { Write-Host "  $_" }
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Telefon $($p.Seri): $Basari" -ForegroundColor Green
        } else {
            Write-Host "Telefon $($p.Seri): islem basarisiz (kod $LASTEXITCODE)." -ForegroundColor Yellow
            $code = 1
        }
    }
    return $code
}

function Start-Internet {
    if ((Get-RelayIslemleri).Count -gt 0) {
        Write-Host 'Internet verme zaten acik. Once Kapat secenegini kullanin.' -ForegroundColor Yellow
        return 1
    }
    Write-Host 'Telefona internet veriliyor. Ilk seferde telefonda "Baglanti istegi" (VPN) sorusunu onaylayin.'
    Write-Host 'Bu pencereyi kapatinca bilgisayar tarafi biter; telefondaki VPN icin Kapat secenegini kullanin.' -ForegroundColor Yellow
    Set-Location -LiteralPath $taskDir
    Invoke-Adb @('start-server') | Out-Null
    & $taskExe autorun | Out-Host
    return $LASTEXITCODE
}

function Invoke-Islem {
    param([string]$Ad)
    switch ($Ad) {
        'Durum'  { Show-Durum; return 0 }
        'Baslat' { return (Start-Internet) }
        'Durdur' { Stop-Hepsi; return 0 }
        'Kur'    { return (Invoke-HerTelefon 'install' 'uygulama kuruldu.') }
        'Kaldir' {
            Stop-Hepsi
            return (Invoke-HerTelefon 'uninstall' 'uygulama kaldirildi.')
        }
    }
}

if ($Islem) {
    exit (Invoke-Islem $Islem)
}

Write-Host 'Cep Kopru - Telefona USB internet yoneticisi (gnirehtet)' -ForegroundColor Cyan
Write-Host 'Yonetici izni gerekmez. Telefonda USB hata ayiklama acik olmali.'
while ($true) {
    Write-Host ''
    Show-Durum
    Write-Host ''
    Write-Host '1) Durumu yenile'
    Write-Host '2) Telefona internet ver (baslat)'
    Write-Host '3) Telefondaki VPN''i ve internet vermeyi kapat'
    Write-Host '4) Telefona uygulamayi kur'
    Write-Host '5) Telefondan uygulamayi kaldir'
    Write-Host '0) Cikis'
    $secim = Read-Host 'Seciminiz'
    switch ($secim) {
        '1' { }
        '2' { Invoke-Islem 'Baslat' | Out-Null }
        '3' { Invoke-Islem 'Durdur' | Out-Null }
        '4' { Invoke-Islem 'Kur' | Out-Null }
        '5' { Invoke-Islem 'Kaldir' | Out-Null }
        '0' { exit 0 }
        default { Write-Host 'Gecersiz secim.' -ForegroundColor Yellow }
    }
}
