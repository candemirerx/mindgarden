﻿# Bilgisayarin internetini USB kablosuyla telefona verir (ters USB paylasim).
# Yonetici izni, Wi-Fi yayini veya Windows Internet Paylasimi kullanmaz.
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
$taskDir=Join-Path $PSScriptRoot 'vendor/gnirehtet'
Get-ChildItem -LiteralPath $taskDir -File | Unblock-File -ErrorAction SilentlyContinue
Set-Location -LiteralPath $taskDir
$env:ADB=Join-Path $taskDir 'adb.exe'
$env:GNIREHTET_APK=Join-Path $taskDir 'gnirehtet.apk'
Write-Host 'Cep Kopru - Telefona USB internet' -ForegroundColor Cyan
Write-Host '1. Telefonda Gelistirici secenekleri > USB hata ayiklama acik olsun.'
Write-Host '2. Telefonu kabloyla takin; telefonda cikan "USB hata ayiklamaya izin ver" sorusunu onaylayin.'
Write-Host '3. Ilk seferde telefonda "Baglanti istegi" (VPN) sorusunu onaylayin.'
Write-Host 'Not: Bu sirada telefondaki Tailscale gibi baska bir VPN kapanir.' -ForegroundColor Yellow
Write-Host 'Pencere acik kaldigi surece internet verilir.' -ForegroundColor Green
Write-Host 'Pencereyi kapatmak telefondaki VPN''i kapatmaz: 12-Telefona-USB-Internet-Kapat dosyasini calistirin' -ForegroundColor Yellow
Write-Host 'veya telefonda bildirimden Durdur deyin.' -ForegroundColor Yellow
& $env:ADB start-server | Out-Null
& (Join-Path $taskDir 'gnirehtet.exe') autorun
exit $LASTEXITCODE
