﻿param([switch]$Wifi, [switch]$NoCard, [switch]$NoBluetooth, [switch]$NoTailscale, [switch]$NoClipboardRead)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
Set-Location -LiteralPath $PSScriptRoot
Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
Write-Host 'Cep Kopru PC Yardimcisi 2.7.0' -ForegroundColor Cyan
Write-Host 'Normal kullanici olarak calisir; yonetici izni istemez.'
$taskPort=8775
$taskExtra=@()
if($NoCard) { $taskExtra+='-NoCard' }
if($NoBluetooth) { $taskExtra+='-NoBluetooth' }
if($NoClipboardRead) { $taskExtra+='-NoClipboardRead' }
# Always repair/maintain the phone bridge, even when the helper is already open.
$taskUsbBridge=Join-Path $PSScriptRoot 'usb_baglanti.ps1'
if(Test-Path -LiteralPath $taskUsbBridge) {
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$taskUsbBridge+'"'),'-NoHelperStart')
}
try {
    $taskHealth=Invoke-RestMethod -Uri "http://127.0.0.1:$taskPort/hello" -TimeoutSec 2
    if($taskHealth.app -eq 'cep-kopru-pc') {
        if ([bool]$taskHealth.clipboardReadBlocked -ne [bool]$NoClipboardRead) {
            Write-Host 'Acik yardimci farkli pano guvenlik modunda. Once onu kapatin, sonra bu modu baslatin.' -ForegroundColor Yellow
            exit 1
        }
        if ($Wifi -and -not $taskHealth.lanAccess) {
            Write-Host 'Yardimci zaten acik ancak yerel ag modu kapali (veya eski surum). Once acik yardimciyi kapatin, sonra Wi-Fi ile baslatin.' -ForegroundColor Yellow
            exit 1
        }
        Write-Host ('Cep Kopru yardimcisi zaten acik. Surum: ' + $taskHealth.helperVersion) -ForegroundColor Green
        Write-Host 'Telefonda bilgisayara baglanti istegi gonderin. Onay ayri, gorunur bir pencerede acilir.'
        Write-Host 'Acik bir konsol bulmaniz veya onu aramaniz gerekmez.'
        if (-not $taskHealth.pairApproval) { Write-Warning 'Bu acik yardimci onay penceresini desteklemiyor. Eski yardimciyi kapatip yeni paketi baslatin.' }
        exit 0
    }
} catch { }
if(-not $Wifi) {
  if($NoTailscale) {
    Write-Host 'Isyeri modu: Tailscale ve bilgisayar Wi-Fi baglantisi kullanilmaz.' -ForegroundColor Cyan
    Write-Host $(if($NoBluetooth) { 'Calisan kanallar: kart USB (karttan pano, USB internet) ve telefon USB kablosu.' } else { 'Calisan kanallar: kart USB (karttan pano, USB internet), telefon USB kablosu ve bilgisayar Bluetooth.' })
  } else {
    $taskTailscale=Get-Command tailscale.exe -ErrorAction SilentlyContinue
    if(-not $taskTailscale) {
        $taskCandidate=Join-Path $env:ProgramFiles 'Tailscale/tailscale.exe'
        if(Test-Path -LiteralPath $taskCandidate) { $taskTailscale=Get-Item -LiteralPath $taskCandidate }
    }
    if($taskTailscale) {
        $taskExe=if($taskTailscale.Source) { $taskTailscale.Source } else { $taskTailscale.FullName }
        try {
            $taskState=(& $taskExe status --json | ConvertFrom-Json)
            if($LASTEXITCODE -ne 0 -or $taskState.BackendState -ne 'Running') { throw 'Tailscale oturumu acik degil.' }
            $taskServe=(& $taskExe serve status --json | ConvertFrom-Json)
            if($LASTEXITCODE -ne 0) { throw 'Tailscale yonlendirmesi okunamadi.' }
            $taskExisting=$taskServe.TCP."$taskPort"
            $taskTarget="127.0.0.1:$taskPort"
            if($taskExisting -and $taskExisting.TCPForward -ne $taskTarget) {
                throw '8775 portu baska bir Tailscale yayini tarafindan kullaniliyor. Mevcut yayin degistirilmedi.'
            }
            if(-not $taskExisting) {
                & $taskExe serve --bg --tcp=$taskPort "tcp://$taskTarget"
                if($LASTEXITCODE -ne 0) { throw 'Tailscale yonlendirmesine izin verilmedi. Sistem politikasini yoneticiniz kontrol edebilir.' }
            }
            $taskState.TailscaleIPs | Where-Object { $_ -like '100.*' } | ForEach-Object {
                Write-Host "Telefondaki bilgisayar adresi: http://${_}:$taskPort" -ForegroundColor Green
            }
        } catch { Write-Warning $_.Exception.Message; Write-Host 'Kart USB ve Bluetooth kanallari yine acilacak.' }
    } else {
        Write-Host 'Tailscale bulunamadi. Kart USB ve Bluetooth kullanilabilir.' -ForegroundColor Yellow
        Write-Host 'Ayni agda baglanmak icin Wi-Fi ile baslat.cmd dosyasini kullanin.'
    }
  }
    & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'pc_clipboard_helper.ps1') -Port $taskPort -LoopbackOnly @taskExtra
} else {
    Write-Host 'Wi-Fi modu: Windows gelen baglantiyi engellerse mevcut bir guvenlik duvari izni gerekir.' -ForegroundColor Yellow
    Write-Host 'Program guvenlik duvarini degistirmez ve yonetici penceresi acmaz.'
    & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'pc_clipboard_helper.ps1') -Port $taskPort @taskExtra
}
exit $LASTEXITCODE
