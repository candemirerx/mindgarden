﻿' Verilen PowerShell dosyasini ayni klasorden, pencere acmadan baslatir.
' Kullanim: wscript.exe gizli_baslat.vbs dosya.ps1 [ek bagimsiz degiskenler]
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
If WScript.Arguments.Count = 0 Then WScript.Quit 2
komut = "powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File """ & dir & "\" & WScript.Arguments(0) & """"
For i = 1 To WScript.Arguments.Count - 1
    komut = komut & " " & WScript.Arguments(i)
Next
sh.Run komut, 0, False
