# Not Bahcesi PC yardimcisi icin Windows guvenlik duvari izni.
#
# Yardimci program TCP 8765 portunda dinler. Windows gelen baglantilari
# varsayilan olarak engelledigi icin telefon ayni Wi-Fi aginda olsa bile bu
# porta baglanamaz: "PC panosuna gonder", fare, kısayol ve dikte sessizce
# calismaz. Bu betik izin kuralini bir kez ekler ve ag profili Ozel degilse
# kullaniciyi acikca uyarir. Yonetici hakki gerektirir.
#
# -Denetle: yalniz bakar (yonetici gerekmez). Izin hazirsa 0, eklenmesi
# gerekiyorsa 1 doner; baslatici yonetici iznini yalniz o zaman bir kez ister.
#
# -Tailscale: kurali, Tailscale agindaki (100.64.0.0/10) kendi cihazlarinizdan
# gelen baglantilara da acar; telefon baska sehirden Tailscale ile baglanabilir.
# Yardimci yine de 6 haneli kodla eslestirme ister. -TailscaleKaldir bu izni
# geri alir (yalniz yerel ag kalir). Kuralda Tailscale izni varsa, normal
# calistirmada korunur.
param([switch]$Denetle, [switch]$Tailscale, [switch]$TailscaleKaldir)
$ErrorActionPreference = 'Stop'
$kuralAdi = 'Not Bahcesi PC yardimcisi (TCP 8765)'
$port = 8765

if ($Denetle) {
    try {
        $hazir = @(Get-NetFirewallRule -DisplayName $kuralAdi -ErrorAction SilentlyContinue |
            Where-Object { $_.Enabled -eq 'True' -and $_.Action -eq 'Allow' }).Count -gt 0
        $psYolu = Join-Path $PSHOME 'powershell.exe'
        $engel = @(Get-NetFirewallApplicationFilter -Program $psYolu -ErrorAction SilentlyContinue |
            Get-NetFirewallRule | Where-Object { $_.Enabled -eq 'True' -and $_.Direction -eq 'Inbound' -and $_.Action -eq 'Block' -and $_.Name -like 'TCP Query User*' -and ([int]$_.Profile -band 2) -ne 0 }).Count -gt 0
        $taskCompatRule = Get-NetFirewallRule -DisplayName 'Not Bahcesi PowerShell diger TCP portlari' -ErrorAction SilentlyContinue
        $taskCompatPorts = @($taskCompatRule | Get-NetFirewallPortFilter | ForEach-Object { $_.LocalPort }) -join ','
        $taskCompatReady = -not $taskCompatRule -or $taskCompatPorts -eq '1-8764,8766-8774,8776-65535'
        if ($hazir -and -not $engel -and $taskCompatReady) { exit 0 }
    } catch { }
    exit 1
}

$kimlik = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$yonetici = (New-Object System.Security.Principal.WindowsPrincipal($kimlik)).IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $yonetici) {
    Write-Host 'Guvenlik duvari izni icin yonetici hakki gerekir.' -ForegroundColor Yellow
    exit 1
}

# Windows'un onceki izin penceresinde "Iptal" secilmesi PowerShell icin
# tum portlari engelleyen kurallar olusturur. Acik engel, port izninden ustundur.
# Iki yardimcinin portunu ayir: 8765 Not Bahcesi, 8775 Cep Kopru.
# Kullanicinin mevcut Windows engelini tumden kaldirma; Ortak ag korunur.
$taskPowerShellPath = Join-Path $PSHOME 'powershell.exe'
$taskOtherPortsName = 'Not Bahcesi PowerShell diger TCP portlari'
$taskSafePorts = @('1-8764','8766-8774','8776-65535')
$taskOldRule = Get-NetFirewallRule -DisplayName $taskOtherPortsName -ErrorAction SilentlyContinue
if ($taskOldRule) {
    $taskOldRule | Get-NetFirewallPortFilter | Set-NetFirewallPortFilter -LocalPort $taskSafePorts
    Write-Host 'Eski engel duzeltildi: TCP 8765 ve 8775 engellenmiyor.' -ForegroundColor Green
}
$taskPrivateBlocks = @(Get-NetFirewallApplicationFilter -Program $taskPowerShellPath -ErrorAction SilentlyContinue |
    Get-NetFirewallRule | Where-Object { $_.Enabled -eq 'True' -and $_.Direction -eq 'Inbound' -and $_.Action -eq 'Block' -and $_.Name -like 'TCP Query User*' -and ([int]$_.Profile -band 2) -ne 0 })
if ($taskPrivateBlocks.Count -gt 0) {
    if (-not (Get-NetFirewallRule -DisplayName $taskOtherPortsName -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName $taskOtherPortsName -Direction Inbound -Action Block -Program $taskPowerShellPath -Protocol TCP -LocalPort $taskSafePorts -Profile Private | Out-Null
    }
    foreach ($taskBlock in $taskPrivateBlocks) {
        $taskRemainingProfiles = [int]$taskBlock.Profile -band (-bnot 2)
        if ($taskRemainingProfiles -eq 0) { $taskBlock | Disable-NetFirewallRule | Out-Null }
        else { $taskBlock | Set-NetFirewallRule -Profile $taskRemainingProfiles | Out-Null }
    }
    Write-Host 'Onceki PowerShell engelinde TCP 8765 ve 8775 istisnalari hazirlandi; diger korumalar korundu.' -ForegroundColor Green
}

$kural = $null
try { $kural = Get-NetFirewallRule -DisplayName $kuralAdi -ErrorAction SilentlyContinue } catch { $kural = $null }

# Uzak adresler: yerel ag + (istenmisse ya da onceden verilmisse) Tailscale agi.
$tsVar = $false
if ($kural) { try { $tsVar = (@(($kural | Get-NetFirewallAddressFilter).RemoteAddress) -join ',') -match '100\.64\.0\.0' } catch { } }
$adresler = if (($Tailscale -or $tsVar) -and -not $TailscaleKaldir) { @('LocalSubnet', '100.64.0.0/10') } else { @('LocalSubnet') }

if ($kural) {
    $kural | Set-NetFirewallRule -Enabled True -Direction Inbound -Action Allow -Profile Private
    $kural | Get-NetFirewallAddressFilter | Set-NetFirewallAddressFilter -RemoteAddress $adresler
    Write-Host ('Guvenlik duvari izni zaten var: ' + $kuralAdi) -ForegroundColor Green
    if ($adresler.Count -gt 1) { Write-Host 'Tailscale agindan (100.64.0.0/10) gelen baglantilara da izin verildi.' -ForegroundColor Green }
    elseif ($TailscaleKaldir) { Write-Host 'Tailscale izni kaldirildi; yalniz yerel ag kaldi.' -ForegroundColor Green }
} else {
    try {
        New-NetFirewallRule -DisplayName $kuralAdi -Direction Inbound -Action Allow -Protocol TCP -LocalPort $port -Profile Private -RemoteAddress $adresler -Description 'Not Bahcesi telefon-PC bagi (yerel ag; istenirse Tailscale)' | Out-Null
        Write-Host ('Guvenlik duvari izni eklendi: TCP ' + $port + ' (yalniz Ozel ag profili).') -ForegroundColor Green
    } catch {
        Write-Host ('Guvenlik duvari izni eklenemedi: ' + $_.Exception.Message) -ForegroundColor Red
        exit 2
    }
}

# Kural yalniz Ozel profilde gecerlidir; ag Ortak (Public) profildeyse
# telefon yine baglanamaz, bu yuzden acik uyari verilir.
$acik = @(Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object { $_.NetworkCategory -ne 'Private' -and $_.IPv4Connectivity -ne 'Disconnected' })
if ($acik.Count -gt 0) {
    Write-Host 'UYARI: Su aglar Ozel profilde degil; izin kurali bu aglarda islemez:' -ForegroundColor Yellow
    foreach ($ag in $acik) { Write-Host ('  - ' + $ag.Name + ' (' + $ag.NetworkCategory + ')') -ForegroundColor Yellow }
    Write-Host 'Windows Ayarlari > Ag ve Internet > Wi-Fi > ag adi > Ag profili: Ozel secin.' -ForegroundColor Yellow
}
exit 0
