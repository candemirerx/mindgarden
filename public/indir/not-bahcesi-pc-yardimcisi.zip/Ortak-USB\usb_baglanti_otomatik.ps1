$ErrorActionPreference = 'Stop'
$taskDestination = Join-Path $env:LOCALAPPDATA 'CepKopruUsbBridge'
New-Item -ItemType Directory -Path $taskDestination -Force | Out-Null
if ([IO.Path]::GetFullPath($PSScriptRoot) -ne [IO.Path]::GetFullPath($taskDestination)) {
    Get-ChildItem -LiteralPath $PSScriptRoot -Force | Where-Object { $_.Name -ne 'logs' -and ($_.Name -ne '.cep_kopru_token' -or -not (Test-Path -LiteralPath (Join-Path $taskDestination '.cep_kopru_token'))) } | Copy-Item -Destination $taskDestination -Recurse -Force
}
$taskScript = Join-Path $taskDestination 'usb_baglanti.ps1'
$taskLinkPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'Cep Kopru Telefon USB.lnk'
$taskShell = New-Object -ComObject WScript.Shell
$taskLink = $taskShell.CreateShortcut($taskLinkPath)
$taskLink.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$taskLink.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$taskScript+'" -Background'
$taskLink.WorkingDirectory = $taskDestination
$taskLink.WindowStyle = 7
$taskLink.Save()
Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$taskScript+'"'),'-Background')
Write-Host 'USB koprusu kuruldu. Windows oturumu acilinca otomatik baslar. Yonetici ve guvenlik duvari izni gerekmez.'
Write-Host 'Telefonda USB hata ayiklama ve bilgisayar yetkisi gereklidir. Ilk uygulama baglantisini bilgisayardan onaylayin.'
