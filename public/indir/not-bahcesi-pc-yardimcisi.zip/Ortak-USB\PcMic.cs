using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

// Telefon mikrofonunu bilgisayara mikrofon olarak verir.
//
// Windows'ta "sanal mikrofon" yazilimdan uretilemez: ses, bir sanal ses
// kablosunun CIKIS (render) ucuna yazilir, surucu de onu bir GIRIS (capture)
// aygiti olarak gosterir. Ornegin VB-CABLE kurulduysa buraya "CABLE Input"
// yazilir, PC uygulamalari da mikrofon olarak "CABLE Output" secer.
// Bu sinif yalnizca render ucuna yazar; hicbir surucu kurmaz.
public static class PcMic
{
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] private class MMDeviceEnumeratorCom { }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator {
        [PreserveSig] int EnumAudioEndpoints(int dataFlow, int stateMask, out IMMDeviceCollection devices);
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
    }

    [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceCollection {
        [PreserveSig] int GetCount(out uint count);
        [PreserveSig] int Item(uint index, out IMMDevice device);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice {
        [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object instance);
        [PreserveSig] int OpenPropertyStore(int access, out IPropertyStore store);
        [PreserveSig] int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetState(out int state);
    }

    [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IPropertyStore {
        [PreserveSig] int GetCount(out uint count);
        [PreserveSig] int GetAt(uint index, out PropertyKey key);
        [PreserveSig] int GetValue(ref PropertyKey key, out PropVariant value);
        [PreserveSig] int SetValue(ref PropertyKey key, ref PropVariant value);
        [PreserveSig] int Commit();
    }

    [StructLayout(LayoutKind.Sequential)] private struct PropertyKey { public Guid formatId; public int propertyId; }

    [StructLayout(LayoutKind.Explicit)] private struct PropVariant {
        [FieldOffset(0)] public short type;
        [FieldOffset(8)] public IntPtr pointerValue;
    }

    [ComImport, Guid("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioClient {
        [PreserveSig] int Initialize(int shareMode, int streamFlags, long bufferDuration, long periodicity, IntPtr format, IntPtr sessionGuid);
        [PreserveSig] int GetBufferSize(out uint frames);
        [PreserveSig] int GetStreamLatency(out long latency);
        [PreserveSig] int GetCurrentPadding(out uint frames);
        [PreserveSig] int IsFormatSupported(int shareMode, IntPtr format, out IntPtr closest);
        [PreserveSig] int GetMixFormat(out IntPtr format);
        [PreserveSig] int GetDevicePeriod(out long defaultPeriod, out long minimumPeriod);
        [PreserveSig] int Start();
        [PreserveSig] int Stop();
        [PreserveSig] int Reset();
        [PreserveSig] int SetEventHandle(IntPtr handle);
        [PreserveSig] int GetService(ref Guid iid, [MarshalAs(UnmanagedType.IUnknown)] out object service);
    }

    [ComImport, Guid("F294ACFC-3146-4483-A7BF-ADDCA7C260E2"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioRenderClient {
        [PreserveSig] int GetBuffer(uint frames, out IntPtr data);
        [PreserveSig] int ReleaseBuffer(uint frames, uint flags);
    }

    private static readonly PropertyKey FriendlyName = MakeKey("a45c254e-df1c-4efd-8020-67d146a850e0", 14);

    private static PropertyKey MakeKey(string guid, int id)
    {
        PropertyKey key = new PropertyKey();
        key.formatId = new Guid(guid);
        key.propertyId = id;
        return key;
    }

    private static readonly object gate = new object();
    private static TcpClient current;
    private static int generation;
    private static string wantedDevice = "";
    private static volatile bool streaming;

    public static string LastError = "";
    public static bool Streaming { get { return streaming; } }
    public static string Device { get { lock (gate) return wantedDevice; } }

    /** Render (cikis) aygitlarinin okunur adlari; telefon bu listeden secer. */
    public static string[] Outputs()
    {
        List<string> names = new List<string>();
        IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
        IMMDeviceCollection devices;
        // dataFlow 0 = render, stateMask 1 = yalniz etkin aygitlar.
        Check(enumerator.EnumAudioEndpoints(0, 1, out devices), "Ses cikislari listelenemedi");
        uint count;
        Check(devices.GetCount(out count), "Ses cikisi sayisi okunamadi");
        for (uint i = 0; i < count; i++) {
            IMMDevice device;
            if (devices.Item(i, out device) < 0) continue;
            string name = NameOf(device);
            if (name.Length > 0) names.Add(name);
        }
        return names.ToArray();
    }

    /**
     * Sanal ses kablosunun giris ucunu tahmin eder. Kullanici bir aygit
     * secmediyse bu ad kullanilir; bulunamazsa bos doner (gercek hoparlore
     * asla kendiliginden yazilmaz, yoksa kendi sesinizi duyarsiniz).
     */
    public static string GuessVirtualOutput()
    {
        string[] all = Outputs();
        string[] hints = new string[] { "CABLE Input", "VoiceMeeter Input", "VoiceMeeter Aux Input",
            "Virtual Speakers", "Virtual Audio Cable", "Line 1" };
        foreach (string hint in hints)
            foreach (string name in all)
                if (name.IndexOf(hint, StringComparison.OrdinalIgnoreCase) >= 0) return name;
        return "";
    }

    private static string NameOf(IMMDevice device)
    {
        IPropertyStore store = null;
        try {
            if (device.OpenPropertyStore(0, out store) < 0 || store == null) return "";
            PropertyKey key = FriendlyName;
            PropVariant value;
            if (store.GetValue(ref key, out value) < 0) return "";
            if (value.pointerValue == IntPtr.Zero) return "";
            string name = Marshal.PtrToStringUni(value.pointerValue);
            return name == null ? "" : name;
        } catch { return ""; }
        finally { if (store != null) Marshal.ReleaseComObject(store); }
    }

    private static IMMDevice FindRender(string wanted)
    {
        IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
        if (string.IsNullOrEmpty(wanted))
            throw new InvalidOperationException("Sanal mikrofon aygiti secilmedi.");
        IMMDeviceCollection devices;
        Check(enumerator.EnumAudioEndpoints(0, 1, out devices), "Ses cikislari listelenemedi");
        uint count;
        Check(devices.GetCount(out count), "Ses cikisi sayisi okunamadi");
        for (uint i = 0; i < count; i++) {
            IMMDevice device;
            if (devices.Item(i, out device) < 0) continue;
            if (string.Equals(NameOf(device), wanted, StringComparison.OrdinalIgnoreCase)) return device;
        }
        throw new InvalidOperationException("Ses cikisi bulunamadi: " + wanted);
    }

    public static void Configure(string device)
    {
        lock (gate) wantedDevice = device == null ? "" : device.Trim();
    }

    /** Telefon baglantisini devralir; ayni anda tek mikrofon akisi olur. */
    public static void Serve(TcpClient client, string device)
    {
        int mine;
        lock (gate) {
            if (!string.IsNullOrEmpty(device)) wantedDevice = device.Trim();
            if (current != null) { try { current.Close(); } catch { } }
            current = client;
            mine = ++generation;
        }
        Thread worker = new Thread(delegate() { Run(client, mine); });
        worker.IsBackground = true;
        worker.Name = "Cep Kopru telefon mikrofonu";
        worker.SetApartmentState(ApartmentState.MTA);
        worker.Start();
    }

    public static void StopAll()
    {
        lock (gate) {
            generation++;
            if (current != null) { try { current.Close(); } catch { } current = null; }
        }
    }

    private static bool Alive(int mine) { lock (gate) { return mine == generation; } }

    private static void Check(int hr, string what)
    {
        if (hr < 0) throw new InvalidOperationException(what + " (0x" + hr.ToString("X8") + ")");
    }

    private static int ReadExact(NetworkStream stream, byte[] buffer, int count)
    {
        int total = 0;
        while (total < count) {
            int n = stream.Read(buffer, total, count - total);
            if (n <= 0) return total;
            total += n;
        }
        return total;
    }

    private static void Run(TcpClient client, int mine)
    {
        IAudioClient audio = null;
        IntPtr mix = IntPtr.Zero;
        NetworkStream stream = null;
        string target;
        lock (gate) target = wantedDevice;
        try {
            client.NoDelay = true;
            client.ReceiveTimeout = 8000;
            stream = client.GetStream();

            IMMDevice device = FindRender(target);
            Guid audioId = typeof(IAudioClient).GUID;
            object instance;
            Check(device.Activate(ref audioId, 23, IntPtr.Zero, out instance), "Ses cikisi acilamadi");
            audio = (IAudioClient)instance;
            Check(audio.GetMixFormat(out mix), "Ses bicimi okunamadi");

            int tag = Marshal.ReadInt16(mix, 0) & 0xFFFF;
            int channels = Marshal.ReadInt16(mix, 2);
            int rate = Marshal.ReadInt32(mix, 4);
            int blockAlign = Marshal.ReadInt16(mix, 12);
            int bits = Marshal.ReadInt16(mix, 14);
            bool isFloat = tag == 3;
            if (tag == 0xFFFE) {
                byte[] sub = new byte[16];
                Marshal.Copy(new IntPtr(mix.ToInt64() + 24), sub, 0, 16);
                isFloat = new Guid(sub) == new Guid("00000003-0000-0010-8000-00aa00389b71");
            }
            if (channels < 1 || rate < 8000 || rate > 192000) throw new InvalidOperationException("Desteklenmeyen ses bicimi");
            if (isFloat && bits != 32) throw new InvalidOperationException("Desteklenmeyen kayan noktali bicim");
            if (!isFloat && bits != 16 && bits != 32) throw new InvalidOperationException("Desteklenmeyen ornek boyutu");

            // 100 ms arabellek: telefon Wi-Fi'de dalgalansa da ses kesilmesin.
            Check(audio.Initialize(0, 0, 1000000, 0, mix, IntPtr.Zero), "Ses cikisi baslatilamadi");
            uint bufferFrames;
            Check(audio.GetBufferSize(out bufferFrames), "Arabellek boyutu okunamadi");
            Guid renderId = typeof(IAudioRenderClient).GUID;
            object renderObject;
            Check(audio.GetService(ref renderId, out renderObject), "Ses yazici alinamadi");
            IAudioRenderClient render = (IAudioRenderClient)renderObject;

            // Telefon basligi: "CKM1" + rate(4) + channels(2) + bits(2)
            byte[] head = new byte[12];
            if (ReadExact(stream, head, 12) != 12) throw new InvalidOperationException("Mikrofon basligi eksik");
            if (Encoding.ASCII.GetString(head, 0, 4) != "CKM1") throw new InvalidOperationException("Mikrofon basligi gecersiz");
            int srcRate = BitConverter.ToInt32(head, 4);
            int srcChannels = BitConverter.ToInt16(head, 8);
            int srcBits = BitConverter.ToInt16(head, 10);
            if (srcRate < 8000 || srcRate > 48000 || srcChannels < 1 || srcChannels > 2 || srcBits != 16)
                throw new InvalidOperationException("Telefon ses bicimi desteklenmiyor");

            Check(audio.Start(), "Ses cikisi calistirilamadi");
            streaming = true;

            byte[] chunk = new byte[srcRate * srcChannels * 2 / 10]; // ~100 ms
            // Telefon orneklerinden aygit hizina basit dogrusal yeniden ornekleme.
            double step = (double)srcRate / rate;
            double cursor = 0;
            short[] pending = new short[0];
            int pendingFrames = 0;

            while (Alive(mine)) {
                int read = stream.Read(chunk, 0, chunk.Length);
                if (read <= 0) break;
                int frames = read / (srcChannels * 2);
                if (frames <= 0) continue;
                if (pending.Length < (pendingFrames + frames) * srcChannels)
                    Array.Resize(ref pending, (pendingFrames + frames) * srcChannels * 2);
                for (int i = 0; i < frames * srcChannels; i++)
                    pending[pendingFrames * srcChannels + i] = BitConverter.ToInt16(chunk, i * 2);
                pendingFrames += frames;

                // Cikisa ne kadar sigacagini bul.
                uint padding;
                Check(audio.GetCurrentPadding(out padding), "Arabellek durumu okunamadi");
                uint free = bufferFrames - padding;
                if (free == 0) { Thread.Sleep(5); continue; }

                int available = (int)Math.Floor((pendingFrames - cursor) / step);
                if (available <= 0) continue;
                int write = Math.Min(available, (int)free);
                if (write <= 0) continue;

                IntPtr buffer;
                Check(render.GetBuffer((uint)write, out buffer), "Ses arabellegi alinamadi");
                for (int frame = 0; frame < write; frame++) {
                    int src = (int)(cursor + frame * step);
                    if (src >= pendingFrames) src = pendingFrames - 1;
                    for (int ch = 0; ch < channels; ch++) {
                        int srcChannel = ch < srcChannels ? ch : srcChannels - 1;
                        short sample = pending[src * srcChannels + srcChannel];
                        long offset = buffer.ToInt64() + (long)(frame * blockAlign) + (long)(ch * (bits / 8));
                        if (isFloat) Marshal.Copy(BitConverter.GetBytes(sample / 32768f), 0, new IntPtr(offset), 4);
                        else if (bits == 16) Marshal.Copy(BitConverter.GetBytes(sample), 0, new IntPtr(offset), 2);
                        else Marshal.Copy(BitConverter.GetBytes((int)sample << 16), 0, new IntPtr(offset), 4);
                    }
                }
                Check(render.ReleaseBuffer((uint)write, 0), "Ses arabellegi yazilamadi");

                cursor += write * step;
                int consumed = (int)Math.Floor(cursor);
                if (consumed > 0) {
                    int keep = pendingFrames - consumed;
                    if (keep < 0) keep = 0;
                    Array.Copy(pending, consumed * srcChannels, pending, 0, keep * srcChannels);
                    pendingFrames = keep;
                    cursor -= consumed;
                }
            }
        } catch (Exception error) {
            LastError = error.Message;
        } finally {
            streaming = false;
            if (audio != null) { try { audio.Stop(); } catch { } }
            if (mix != IntPtr.Zero) Marshal.FreeCoTaskMem(mix);
            if (stream != null) { try { stream.Close(); } catch { } }
            try { client.Close(); } catch { }
            lock (gate) { if (current == client) current = null; }
        }
    }
}
