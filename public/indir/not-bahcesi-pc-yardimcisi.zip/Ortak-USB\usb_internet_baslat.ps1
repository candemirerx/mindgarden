﻿param([int]$BaslangicBekleme = 0)
$ErrorActionPreference = 'Stop'
$taskScript = Join-Path $PSScriptRoot 'pc_clipboard_helper.ps1'
if (-not (Test-Path -LiteralPath $taskScript)) { throw 'USB yardimci dosyasi bulunamadi.' }
# Tek denetleyici: ikinci kopya hemen kapanir (kart portunu zaten iscinin kilidi korur).
$taskLease = [System.Threading.Mutex]::new($false, 'Local\CepKopruUsbBaslatici')
$taskHeld = $false
try { $taskHeld = $taskLease.WaitOne(0) } catch [System.Threading.AbandonedMutexException] { $taskHeld = $true }
if (-not $taskHeld) { Write-Host 'USB internet yardimcisi zaten calisiyor.'; exit 0 }
if ($BaslangicBekleme -gt 0) { Start-Sleep -Seconds $BaslangicBekleme }
# COM adi her seferinde USB kimligiyle bulunur; eski bilgisayardan kayit alinmaz.
$logDir = Join-Path $PSScriptRoot 'logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$ErrorActionPreference = 'Continue'
while ($true) {
    $started = Get-Date
    try {
        $stamp = Get-Date -Format 'yyMMdd-HHmmss'
        Get-ChildItem $logDir -Filter 'worker-*.log' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 30 | Remove-Item -Force -ErrorAction SilentlyContinue
        $worker = Start-Process powershell.exe -WindowStyle Hidden -PassThru -ArgumentList @('-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',('"' + $taskScript + '"'),'-CardOnly') -RedirectStandardOutput (Join-Path $logDir ('worker-' + $stamp + '-out.log')) -RedirectStandardError (Join-Path $logDir ('worker-' + $stamp + '-err.log'))
        $worker.WaitForExit()
    } catch { }
    $ran = ((Get-Date) - $started).TotalSeconds
    Start-Sleep -Seconds ([Math]::Max(3, [Math]::Min(15, 15 - [int]$ran)))
}
