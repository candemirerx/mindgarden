﻿param([Parameter(Mandatory)][ValidateSet('Usb','Hepsi','IsyeriPolnet','IsyeriNet','Kaldir')][string]$Tur)
$ErrorActionPreference = 'Stop'
$taskStartup = [Environment]::GetFolderPath('Startup')
$taskLinkPath = Join-Path $taskStartup 'Kablosuz Bellek USB Internet.lnk'
if ($Tur -eq 'Kaldir') {
    if (Test-Path -LiteralPath $taskLinkPath) { Remove-Item -LiteralPath $taskLinkPath -Force; Write-Host 'Baslangic kaydi kaldirildi. Calisan yardimci acik kalir; bilgisayar yeniden baslayinca acilmaz.' }
    else { Write-Host 'Baslangic kaydi zaten yok.' }
    exit 0
}
# Kalici kopya: indirilenler klasoru silinse de baslangic calismaya devam eder.
$taskTarget = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'KablosuzBellekUsbInternet'
New-Item -ItemType Directory -Path $taskTarget -Force | Out-Null
Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -File | Where-Object {
    $_.FullName -notlike (Join-Path $PSScriptRoot 'logs\*') -and $_.Name -ne '.cep_kopru_token'
} | ForEach-Object {
    $relative = $_.FullName.Substring($PSScriptRoot.Length).TrimStart('\')
    $destination = Join-Path $taskTarget $relative
    New-Item -ItemType Directory -Path (Split-Path $destination) -Force | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
}
$taskSourceToken = Join-Path $PSScriptRoot '.cep_kopru_token'
if ((Test-Path -LiteralPath $taskSourceToken) -and -not (Test-Path -LiteralPath (Join-Path $taskTarget '.cep_kopru_token'))) {
    Copy-Item -LiteralPath $taskSourceToken -Destination $taskTarget
}
Get-ChildItem -LiteralPath $taskTarget -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
$taskScript = switch ($Tur) {
    'Usb' { 'usb_internet_baslat.ps1 -BaslangicBekleme 10' }
    'IsyeriPolnet' { 'cep_kopru_baslat.ps1 -NoTailscale -NoBluetooth -NoClipboardRead' }
    'IsyeriNet' { 'cep_kopru_baslat.ps1 -NoTailscale' }
    default { 'cep_kopru_baslat.ps1' }
}
$taskShell = New-Object -ComObject WScript.Shell
$taskLink = $taskShell.CreateShortcut($taskLinkPath)
$taskLink.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
$taskLink.Arguments = '"' + (Join-Path $taskTarget 'gizli_baslat.vbs') + '" ' + $taskScript
$taskLink.WorkingDirectory = $taskTarget
$taskLink.Save()
Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\wscript.exe') -ArgumentList @(('"' + (Join-Path $taskTarget 'gizli_baslat.vbs') + '"'), $taskScript) -WindowStyle Hidden
Write-Host ('Hazir. Her Windows oturumunda gizli acilacak: ' + $(switch ($Tur) { 'Usb' { 'USB internet' } 'IsyeriPolnet' { 'Isyeri Polnet yardimcisi' } 'IsyeriNet' { 'Isyeri Net yardimcisi' } default { 'tam yardimci' } }))
