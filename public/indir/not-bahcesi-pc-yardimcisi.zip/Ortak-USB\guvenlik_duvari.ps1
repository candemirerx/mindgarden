﻿param([Parameter(Mandatory)][ValidateSet('Ekle','Kaldir')][string]$Islem)
$ErrorActionPreference = 'Stop'
$taskRuleName = 'Cep Kopru PC yardimcisi (TCP 8775)'
$taskAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $taskAdmin) {
    Write-Host 'Bu islem yonetici izni ister. Windows onay penceresi acilacak...'
    try {
        $p = Start-Process powershell.exe -Verb RunAs -Wait -PassThru -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"'),'-Islem',$Islem)
        exit $p.ExitCode
    } catch {
        Write-Host 'Yonetici izni verilmedi veya bu hesapta yok. Hicbir sey degistirilmedi.' -ForegroundColor Yellow
        Write-Host 'USB internet, kart panosu ve Tailscale bu izin olmadan da calisir.'
        exit 1
    }
}
Get-NetFirewallRule -DisplayName $taskRuleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
if ($Islem -eq 'Ekle') {
    # Windows'un eski acik engelini tumden kaldirmadan iki yardimciyi ayir.
    $taskCompatName = 'Not Bahcesi PowerShell diger TCP portlari'
    $taskSafePorts = @('1-8764','8766-8774','8776-65535')
    $taskCompatRule = Get-NetFirewallRule -DisplayName $taskCompatName -ErrorAction SilentlyContinue
    if ($taskCompatRule) {
        $taskCompatRule | Get-NetFirewallPortFilter | Set-NetFirewallPortFilter -LocalPort $taskSafePorts
    }
    $taskPsPath = Join-Path $PSHOME 'powershell.exe'
    $taskBlocks = @(Get-NetFirewallApplicationFilter -Program $taskPsPath -ErrorAction SilentlyContinue |
        Get-NetFirewallRule | Where-Object { $_.Enabled -eq 'True' -and $_.Direction -eq 'Inbound' -and $_.Action -eq 'Block' -and $_.Name -like 'TCP Query User*' -and ([int]$_.Profile -band 2) -ne 0 })
    if ($taskBlocks.Count -gt 0) {
        if (-not $taskCompatRule) {
            New-NetFirewallRule -DisplayName $taskCompatName -Direction Inbound -Action Block -Program $taskPsPath -Protocol TCP -LocalPort $taskSafePorts -Profile Private | Out-Null
        }
        foreach ($taskBlock in $taskBlocks) {
            $taskRemaining = [int]$taskBlock.Profile -band (-bnot 2)
            if ($taskRemaining -eq 0) { $taskBlock | Disable-NetFirewallRule | Out-Null }
            else { $taskBlock | Set-NetFirewallRule -Profile $taskRemaining | Out-Null }
        }
    }
    New-NetFirewallRule -DisplayName $taskRuleName -Direction Inbound -Action Allow -Program $taskPsPath -Protocol TCP -LocalPort 8775 -Profile Private -RemoteAddress LocalSubnet | Out-Null
    Write-Host 'Eklendi: TCP 8775, yalniz Ozel ag ve yerel alt ag. 8765 ile cakisma yok.'
    # Izin yalniz Ozel profilde gecerlidir. Ag Ortak ise telefonun istegi hic ulasmaz:
    # bilgisayarda onay penceresi acilmaz ve kullanici sebebini goremez.
    $taskOpen = @(Get-NetConnectionProfile -ErrorAction SilentlyContinue |
        Where-Object { $_.NetworkCategory -ne 'Private' -and $_.IPv4Connectivity -ne 'Disconnected' })
    if ($taskOpen.Count -gt 0) {
        Write-Host ''
        Write-Host 'UYARI: Su aglar Ozel profilde degil; bu izin o aglarda islemez:' -ForegroundColor Yellow
        foreach ($taskNet in $taskOpen) { Write-Host ('  - ' + $taskNet.Name + ' (' + $taskNet.NetworkCategory + ')') -ForegroundColor Yellow }
        Write-Host 'Duzeltme: Ayarlar > Ag ve Internet > Wi-Fi > ag adi > Ag profili turu > Ozel.' -ForegroundColor Yellow
        Write-Host 'Profil Ortak kalirsa telefon eslestirme istegi gonderse de onay penceresi acilmaz.' -ForegroundColor Yellow
    }
} else {
    Write-Host 'Guvenlik duvari izni kaldirildi.'
}
exit 0
